<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\InvoiceTemplateModel;
use CodeIgniter\API\ResponseTrait;

class InvoiceTemplateController extends BaseController
{
    use ResponseTrait;

    public function index()
    {
        $model = new InvoiceTemplateModel();
        $templates = $model->findAll();
        
        $transformed = array_map([$this, 'transformTemplate'], $templates);
        
        return $this->respond($transformed);
    }

    private function transformTemplate($template)
    {
        return [
            'id' => $template['id'],
            'name' => $template['name'],
            'description' => $template['description'],
            'seller' => json_decode($template['seller_json'] ?? '{}', true),
            'defaultCurrency' => $template['default_currency'],
            'defaultTaxCategory' => $template['default_tax_category'],
            'defaultTaxPercent' => (float)$template['default_tax_percent'],
            'defaultPaymentTerms' => json_decode($template['default_payment_terms_json'] ?? '{}', true),
            'logoUrl' => $template['logo_url'],
            'headerText' => $template['header_text'],
            'footerText' => $template['footer_text'],
        ];
    }
}
