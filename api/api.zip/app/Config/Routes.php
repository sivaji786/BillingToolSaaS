<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->post('api/auth/login', '\App\Controllers\AuthController::login');
$routes->get('api/auth/me', '\App\Controllers\AuthController::me');

$routes->get('api/invoices', '\App\Controllers\InvoiceController::index');
$routes->post('api/invoices', '\App\Controllers\InvoiceController::create');
$routes->get('api/invoices/(:segment)', '\App\Controllers\InvoiceController::show/$1');
$routes->put('api/invoices/(:segment)', '\App\Controllers\InvoiceController::update/$1');
$routes->delete('api/invoices/(:segment)', '\App\Controllers\InvoiceController::delete/$1');

$routes->get('api/invoice-templates', '\App\Controllers\InvoiceTemplateController::index');
$routes->get('api/company-profiles', '\App\Controllers\CompanyProfileController::index');
$routes->put('api/company-profiles/(:segment)', '\App\Controllers\CompanyProfileController::update/$1');
$routes->get('api/audit-logs', '\App\Controllers\AuditLogController::index');

$routes->options('(:any)', static function () {
    $response = response();
    $response->setStatusCode(200);
    return $response;
});
