import{r as y,j as e,by as m}from"./vendor-C4M4oQ6k.js";import{B as p,C as Y,a8 as ee,a9 as ae,aa as E,ab as q,ac as U,K as $}from"./ui-kit-DjnpZ4ae.js";import{u as te,c as R,f as g,i as z}from"./index-ByxQQG_q.js";import{I as ce,g as se}from"./invoice-pdf-CmvXH-EI.js";import{ad as re,ae as ne,F as ie,a9 as oe,ac as X,ag as le,ah as w,T as de,a2 as me}from"./vendor-icons-CNu0MI9i.js";import"./vendor-dates-CGa1tBWx.js";import"./vendor-ui-BuoMT1-H.js";import"./vendor-editor-BhSv-Y2W.js";import"./vendor-pdf-tools-C6LU72v4.js";import"./vendor-ai-CU-PfFe-.js";function Ie({invoice:f,onBack:_,onSave:Z,template:j,profile:u}){const{t:c}=te(),[M,H]=y.useState("pdf"),[a,b]=y.useState(f),[N,A]=y.useState(null),[Q,h]=y.useState(!1),[k,F]=y.useState(!1);y.useEffect(()=>{b(f),h(!1)},[f]);const n=(t,s)=>{b(r=>{const o={...r},l=t.split(".");let x=o;for(let P=0;P<l.length-1;P++)x=x[l[P]];return x[l[l.length-1]]=s,o}),h(!0)},C=(t,s,r)=>{b(o=>({...o,lines:o.lines.map(l=>l.id===t?{...l,[s]:r}:l)})),h(!0)},V=()=>{const t={id:String(Date.now()),description:"",quantity:1,unitCode:"EA",unitPrice:0,taxCategory:"S",taxPercent:19};b(s=>({...s,lines:[...s.lines,t]})),h(!0)},G=t=>{b(s=>({...s,lines:s.lines.filter(r=>r.id!==t)})),h(!0)},O=async()=>{try{F(!0);const t=R(a);if(!a.id||a.id.startsWith("new_")){const r=await z.create(t);b(r),m.success(c("common.saved"),{description:c("previewModal.invoiceCreated")||"Invoice created successfully"})}else await z.update(a.id,t),m.success(c("common.saved"),{description:c("previewModal.invoiceUpdated")||"Invoice updated successfully"});h(!1),Z?.(t)}catch(t){console.error("Failed to save invoice:",t),m.error(c("common.error"),{description:c("previewModal.saveFailed")||"Failed to save invoice. Please try again."})}finally{F(!1)}},I=t=>{A(t)},v=()=>{A(null)},i=(t,s,r,o="",l=!1)=>N===t?l?e.jsx(U,{value:s,onChange:x=>r(x.target.value),onBlur:v,autoFocus:!0,className:`${o} min-h-[60px]`}):e.jsx($,{value:s,onChange:x=>r(x.target.value),onBlur:v,autoFocus:!0,className:o}):e.jsxs("div",{onDoubleClick:()=>I(t),className:`${o} cursor-pointer hover:bg-purple-50 dark:hover:bg-purple-950 rounded px-1 transition-colors group relative`,title:"Double-click to edit",children:[s||e.jsx("span",{className:"text-gray-400 italic",children:"Double-click to add"}),e.jsx(w,{className:"h-3 w-3 absolute right-1 top-1 opacity-0 group-hover:opacity-50 text-purple-600"})]}),T=()=>`<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:CustomizationID>urn:cen.eu:en16931:2017</cbc:CustomizationID>
  <cbc:ID>${a.invoiceNumber}</cbc:ID>
  <cbc:IssueDate>${a.issueDate}</cbc:IssueDate>
  ${a.dueDate?`<cbc:DueDate>${a.dueDate}</cbc:DueDate>`:""}
  <cbc:InvoiceTypeCode>${a.invoiceTypeCode||"380"}</cbc:InvoiceTypeCode>
  <cbc:DocumentCurrencyCode>${a.currency}</cbc:DocumentCurrencyCode>
  
  <!-- Seller (Accounting Supplier Party) -->
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:Name>${a.seller.name}</cbc:Name>
      </cac:PartyName>
      <cac:PostalAddress>
        <cbc:StreetName>${a.seller.address.street}</cbc:StreetName>
        <cbc:CityName>${a.seller.address.city}</cbc:CityName>
        <cbc:PostalZone>${a.seller.address.postalCode}</cbc:PostalZone>
        <cac:Country>
          <cbc:IdentificationCode>${a.seller.address.country}</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
      ${a.seller.vatId?`<cac:PartyTaxScheme>
        <cbc:CompanyID>${a.seller.vatId}</cbc:CompanyID>
        <cac:TaxScheme>
          <cbc:ID>VAT</cbc:ID>
        </cac:TaxScheme>
      </cac:PartyTaxScheme>`:""}
    </cac:Party>
  </cac:AccountingSupplierParty>
  
  <!-- Buyer (Accounting Customer Party) -->
  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:Name>${a.buyer.name}</cbc:Name>
      </cac:PartyName>
      <cac:PostalAddress>
        <cbc:StreetName>${a.buyer.address.street}</cbc:StreetName>
        <cbc:CityName>${a.buyer.address.city}</cbc:CityName>
        <cbc:PostalZone>${a.buyer.address.postalCode}</cbc:PostalZone>
        <cac:Country>
          <cbc:IdentificationCode>${a.buyer.address.country}</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
      ${a.buyer.vatId?`<cac:PartyTaxScheme>
        <cbc:CompanyID>${a.buyer.vatId}</cbc:CompanyID>
        <cac:TaxScheme>
          <cbc:ID>VAT</cbc:ID>
        </cac:TaxScheme>
      </cac:PartyTaxScheme>`:""}
    </cac:Party>
  </cac:AccountingCustomerParty>
  
  <!-- Payment Means -->
  ${a.paymentMeans?`<cac:PaymentMeans>
    <cbc:PaymentMeansCode>${a.paymentMeans.type==="BankTransfer"?"30":"1"}</cbc:PaymentMeansCode>
    ${a.paymentMeans.iban?`<cac:PayeeFinancialAccount>
      <cbc:ID>${a.paymentMeans.iban}</cbc:ID>
      ${a.paymentMeans.bic?`<cac:FinancialInstitutionBranch><cbc:ID>${a.paymentMeans.bic}</cbc:ID></cac:FinancialInstitutionBranch>`:""}
    </cac:PayeeFinancialAccount>`:""}
  </cac:PaymentMeans>`:""}
  
  <!-- Tax Total -->
  ${a.taxTotals.map(s=>`<cac:TaxTotal>
    <cbc:TaxAmount currencyID="${a.currency}">${s.taxAmount.toFixed(2)}</cbc:TaxAmount>
    <cac:TaxSubtotal>
      <cbc:TaxableAmount currencyID="${a.currency}">${s.taxableAmount.toFixed(2)}</cbc:TaxableAmount>
      <cbc:TaxAmount currencyID="${a.currency}">${s.taxAmount.toFixed(2)}</cbc:TaxAmount>
      <cac:TaxCategory>
        <cbc:ID>${s.taxCategory||"S"}</cbc:ID>
        <cbc:Percent>${s.taxPercent}</cbc:Percent>
        <cac:TaxScheme>
          <cbc:ID>${s.taxType}</cbc:ID>
        </cac:TaxScheme>
      </cac:TaxCategory>
    </cac:TaxSubtotal>
  </cac:TaxTotal>`).join(`
  `)}
  
  <!-- Legal Monetary Total -->
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="${a.currency}">${a.lineExtensionAmount.toFixed(2)}</cbc:LineExtensionAmount>
    <cbc:TaxExclusiveAmount currencyID="${a.currency}">${a.taxExclusiveAmount.toFixed(2)}</cbc:TaxExclusiveAmount>
    <cbc:TaxInclusiveAmount currencyID="${a.currency}">${a.taxInclusiveAmount.toFixed(2)}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="${a.currency}">${a.payableAmount.toFixed(2)}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>
  
  <!-- Invoice Lines -->
  ${a.lines.map((s,r)=>`<cac:InvoiceLine>
    <cbc:ID>${r+1}</cbc:ID>
    <cbc:InvoicedQuantity unitCode="${s.unitCode}">${s.quantity}</cbc:InvoicedQuantity>
    <cbc:LineExtensionAmount currencyID="${a.currency}">${(s.quantity*s.unitPrice).toFixed(2)}</cbc:LineExtensionAmount>
    <cac:Item>
      <cbc:Name>${s.description}</cbc:Name>
    </cac:Item>
    <cac:Price>
      <cbc:PriceAmount currencyID="${a.currency}">${s.unitPrice.toFixed(2)}</cbc:PriceAmount>
    </cac:Price>
    <cac:TaxTotal>
      <cbc:TaxAmount currencyID="${a.currency}">${(s.quantity*s.unitPrice*s.taxPercent/100).toFixed(2)}</cbc:TaxAmount>
    </cac:TaxTotal>
  </cac:InvoiceLine>`).join(`
  `)}
</Invoice>`,K=()=>{navigator.clipboard.writeText(T()),m.success(c("common.copied"),{description:c("previewModal.copiedToClipboard")})},W=()=>{const t=new Blob([T()],{type:"application/xml"}),s=URL.createObjectURL(t),r=document.createElement("a");r.href=s,r.download=`${a.invoiceNumber}.xml`,r.click(),URL.revokeObjectURL(s),m.success(c("common.downloaded"),{description:`${a.invoiceNumber}.xml`})},J=async()=>{try{const t=m.loading(c("common.loading"),{description:c("previewModal.generatingPdf")||"Generating PDF..."});await se(a,j,u),m.dismiss(t),m.success(c("common.downloaded"),{description:`${a.invoiceNumber}.pdf`})}catch(t){console.error("PDF generation error:",t),m.error(c("common.error"),{description:c("previewModal.pdfGenerationFailed")||"Failed to generate PDF"})}},D=R(a),S=j?.logoUrl||u?.logoUrl,L=j?.headerText||u?.headerText,B=j?.footerText||u?.footerText,d={...a,paymentMeans:a.paymentMeans?.iban?a.paymentMeans:u?.bankAccount?{type:"BankTransfer",iban:u.bankAccount.iban,bic:u.bankAccount.bic,accountName:u.bankAccount.accountName}:void 0};return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs(p,{variant:"outline",onClick:_,children:[e.jsx(re,{className:"h-4 w-4 mr-2"}),c("common.back")]}),Q&&e.jsxs(p,{onClick:O,disabled:k,className:"bg-gradient-to-r from-violet-600 via-purple-600 to-fuchsia-600 text-white",children:[e.jsx(ne,{className:"h-4 w-4 mr-2"}),k?c("common.saving")||"Saving...":c("common.save")]})]}),e.jsx(Y,{className:"p-6",children:e.jsxs(ee,{value:M,onValueChange:t=>H(t),children:[e.jsxs("div",{className:"flex items-center justify-between mb-6",children:[e.jsxs(ae,{className:"bg-white shadow-md border-2 border-purple-100",children:[e.jsxs(E,{value:"pdf",className:"data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-600 data-[state=active]:via-purple-600 data-[state=active]:to-fuchsia-600 data-[state=active]:text-white",children:[e.jsx(ie,{className:"h-4 w-4 mr-2"}),c("previewModal.pdfPreview")]}),e.jsxs(E,{value:"ubl",className:"data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-600 data-[state=active]:via-purple-600 data-[state=active]:to-fuchsia-600 data-[state=active]:text-white",children:[e.jsx(oe,{className:"h-4 w-4 mr-2"}),c("previewModal.ublXml")]})]}),e.jsx("div",{className:"flex gap-2",children:M==="pdf"?e.jsxs(p,{onClick:J,children:[e.jsx(X,{className:"h-4 w-4 mr-2"}),c("previewModal.downloadPdf")||"Download PDF"]}):e.jsxs(e.Fragment,{children:[e.jsxs(p,{variant:"outline",onClick:K,children:[e.jsx(le,{className:"h-4 w-4 mr-2"}),c("previewModal.copyXml")]}),e.jsxs(p,{onClick:W,children:[e.jsx(X,{className:"h-4 w-4 mr-2"}),c("previewModal.downloadUblXml")]})]})})]}),e.jsx(q,{value:"pdf",className:"mt-0",children:e.jsx("div",{className:"border rounded-lg bg-white shadow-inner",children:e.jsx("div",{className:"p-12",children:e.jsxs("div",{className:"max-w-4xl mx-auto space-y-12 bg-white",children:[S&&e.jsx("div",{className:"flex justify-center pb-6 border-b border-purple-100",children:e.jsx("img",{src:S,alt:"Company Logo",className:"h-16 object-contain"})}),L&&e.jsx("div",{className:"text-center text-sm text-gray-600 pb-6 border-b border-purple-100",dangerouslySetInnerHTML:{__html:L}}),e.jsxs("div",{className:"flex justify-between items-start pb-8 border-b-2 border-purple-200",children:[e.jsxs("div",{children:[e.jsx("h1",{className:"text-primary text-4xl",children:a.seller.name}),e.jsx("div",{className:"mt-3 text-lg",children:i("invoiceNumber",a.invoiceNumber,t=>n("invoiceNumber",t))})]}),e.jsxs("div",{className:"text-right space-y-3",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:c("previewModal.issueDate")}),e.jsx("div",{className:"text-lg",children:i("issueDate",a.issueDate,t=>n("issueDate",t))})]}),a.dueDate&&e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground",children:c("previewModal.dueDate")}),e.jsx("div",{className:"text-lg",children:i("dueDate",a.dueDate,t=>n("dueDate",t))})]})]})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-12",children:[e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-3",children:c("previewModal.from")}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("div",{className:"text-lg",children:i("seller.name",a.seller.name,t=>n("seller.name",t))}),a.seller.vatId&&e.jsxs("div",{className:"text-sm",children:[c("previewModal.vat"),":"," ",i("seller.vatId",a.seller.vatId,t=>n("seller.vatId",t),"inline-block")]}),e.jsxs("div",{className:"mt-3 text-sm space-y-0.5",children:[i("seller.address.street",a.seller.address.street,t=>n("seller.address.street",t),"block"),e.jsxs("div",{children:[i("seller.address.postalCode",a.seller.address.postalCode,t=>n("seller.address.postalCode",t),"inline-block mr-2"),i("seller.address.city",a.seller.address.city,t=>n("seller.address.city",t),"inline-block")]}),i("seller.address.country",a.seller.address.country,t=>n("seller.address.country",t),"block")]})]})]}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-3",children:c("previewModal.billTo")}),e.jsxs("div",{className:"space-y-1",children:[e.jsx("div",{className:"text-lg",children:i("buyer.name",a.buyer.name,t=>n("buyer.name",t))}),a.buyer.vatId&&e.jsxs("div",{className:"text-sm",children:[c("previewModal.vat"),":"," ",i("buyer.vatId",a.buyer.vatId,t=>n("buyer.vatId",t),"inline-block")]}),e.jsxs("div",{className:"mt-3 text-sm space-y-0.5",children:[i("buyer.address.street",a.buyer.address.street,t=>n("buyer.address.street",t),"block"),e.jsxs("div",{children:[i("buyer.address.postalCode",a.buyer.address.postalCode,t=>n("buyer.address.postalCode",t),"inline-block mr-2"),i("buyer.address.city",a.buyer.address.city,t=>n("buyer.address.city",t),"inline-block")]}),i("buyer.address.country",a.buyer.address.country,t=>n("buyer.address.country",t),"block")]})]})]})]}),e.jsxs("div",{children:[e.jsx("div",{className:"flex items-center justify-between mb-4",children:e.jsx("h3",{className:"text-lg",children:c("previewModal.items")})}),e.jsx("div",{className:"border rounded-lg overflow-hidden",children:e.jsxs("table",{className:"w-full",children:[e.jsx("thead",{className:"bg-purple-50 dark:bg-purple-950",children:e.jsxs("tr",{children:[e.jsx("th",{className:"text-center p-3 text-sm w-10",children:"#"}),e.jsx("th",{className:"text-left p-3 text-sm",children:c("previewModal.colDescription")}),e.jsx("th",{className:"text-right p-3 text-sm",children:c("previewModal.quantity")}),e.jsx("th",{className:"text-right p-3 text-sm",children:c("previewModal.unitPrice")}),e.jsx("th",{className:"text-right p-3 text-sm",children:c("previewModal.tax")}),e.jsx("th",{className:"text-right p-3 text-sm",children:c("previewModal.amount")}),e.jsx("th",{className:"w-10"})]})}),e.jsx("tbody",{children:a.lines.map((t,s)=>{const r=t.quantity*t.unitPrice;return e.jsxs("tr",{className:"border-t hover:bg-gray-50 dark:hover:bg-gray-900",children:[e.jsx("td",{className:"p-3 text-center text-muted-foreground",children:s+1}),e.jsx("td",{className:"p-3",children:N===`line.${t.id}.description`?e.jsx(U,{value:t.description,onChange:o=>C(t.id,"description",o.target.value),onBlur:v,autoFocus:!0,className:"min-h-[60px]"}):e.jsxs("div",{onDoubleClick:()=>I(`line.${t.id}.description`),className:"cursor-pointer hover:bg-purple-50 dark:hover:bg-purple-950 rounded px-1 transition-colors group relative min-h-[40px]",title:"Double-click to edit",children:[t.description||e.jsx("span",{className:"text-gray-400 italic",children:"Double-click to add"}),e.jsx(w,{className:"h-3 w-3 absolute right-1 top-1 opacity-0 group-hover:opacity-50 text-purple-600"})]})}),e.jsx("td",{className:"p-3 text-right",children:N===`line.${t.id}.quantity`?e.jsx($,{type:"number",value:t.quantity,onChange:o=>C(t.id,"quantity",parseFloat(o.target.value)||0),onBlur:v,autoFocus:!0,className:"text-right"}):e.jsxs("div",{onDoubleClick:()=>I(`line.${t.id}.quantity`),className:"cursor-pointer hover:bg-purple-50 dark:hover:bg-purple-950 rounded px-1 transition-colors group relative",title:"Double-click to edit",children:[t.quantity,e.jsx(w,{className:"h-3 w-3 absolute right-1 top-1 opacity-0 group-hover:opacity-50 text-purple-600"})]})}),e.jsx("td",{className:"p-3 text-right",children:N===`line.${t.id}.unitPrice`?e.jsx($,{type:"number",step:"0.01",value:t.unitPrice,onChange:o=>C(t.id,"unitPrice",parseFloat(o.target.value)||0),onBlur:v,autoFocus:!0,className:"text-right"}):e.jsxs("div",{onDoubleClick:()=>I(`line.${t.id}.unitPrice`),className:"cursor-pointer hover:bg-purple-50 dark:hover:bg-purple-950 rounded px-1 transition-colors group relative",title:"Double-click to edit",children:[g(t.unitPrice,a.currency),e.jsx(w,{className:"h-3 w-3 absolute right-1 top-1 opacity-0 group-hover:opacity-50 text-purple-600"})]})}),e.jsxs("td",{className:"p-3 text-right text-sm",children:[t.taxPercent,"%"]}),e.jsx("td",{className:"p-3 text-right",children:g(r,a.currency)}),e.jsx("td",{className:"p-3",children:e.jsx(p,{variant:"ghost",size:"icon",onClick:()=>G(t.id),className:"h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50",children:e.jsx(de,{className:"h-4 w-4"})})})]},t.id)})})]})}),e.jsx("div",{className:"mt-2",children:e.jsxs(p,{variant:"outline",size:"sm",onClick:V,className:"gap-2",children:[e.jsx(me,{className:"h-4 w-4"}),c("editor.addLine")||"Add Line"]})})]}),e.jsx("div",{className:"flex justify-end",children:e.jsxs("div",{className:"w-80 space-y-3",children:[e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsx("span",{className:"text-muted-foreground",children:c("previewModal.subtotal")}),e.jsx("span",{children:g(D.lineExtensionAmount,a.currency)})]}),D.taxTotals.map((t,s)=>e.jsxs("div",{className:"flex justify-between text-sm",children:[e.jsxs("span",{className:"text-muted-foreground",children:[t.taxType," (",t.taxPercent,"%)"]}),e.jsx("span",{children:g(t.taxAmount,a.currency)})]},s)),e.jsxs("div",{className:"border-t-2 border-purple-200 pt-3 flex justify-between text-lg",children:[e.jsx("span",{children:c("previewModal.total")}),e.jsx("span",{className:"text-primary",children:g(D.payableAmount,a.currency)})]})]})}),a.note&&e.jsxs("div",{className:"border-t pt-6",children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-2",children:c("previewModal.notes")}),i("note",a.note,t=>n("note",t),"text-sm",!0)]}),(a.paymentTerms?.note||d.paymentMeans?.iban)&&e.jsx("div",{className:"border-t pt-6",children:e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-8 items-start",children:[e.jsxs("div",{children:[a.paymentTerms?.note&&e.jsxs("div",{className:"mb-4",children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-2",children:c("previewModal.paymentTerms")}),e.jsx("p",{className:"text-sm",children:a.paymentTerms.note})]}),d.paymentMeans?.iban&&e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-muted-foreground mb-2",children:c("previewModal.paymentInfo")||"Payment Information"}),e.jsxs("p",{className:"text-sm",children:["IBAN: ",d.paymentMeans.iban]}),d.paymentMeans.bic&&e.jsxs("p",{className:"text-sm",children:["BIC: ",d.paymentMeans.bic]}),d.paymentMeans.accountName&&e.jsxs("p",{className:"text-sm",children:["Account: ",d.paymentMeans.accountName]})]})]}),d.paymentMeans?.iban&&e.jsx("div",{className:"flex justify-center md:justify-end",children:e.jsx(ce,{invoice:d,size:200,showLabel:!0})})]})}),B&&e.jsx("div",{className:"border-t pt-6 text-xs text-gray-600 text-center",dangerouslySetInnerHTML:{__html:B}})]})})})}),e.jsx(q,{value:"ubl",className:"mt-0",children:e.jsx("div",{className:"border rounded-lg bg-gray-50 dark:bg-gray-950",children:e.jsx("pre",{className:"p-6 text-xs",children:T()})})})]})})]})}export{Ie as InvoicePreview};
